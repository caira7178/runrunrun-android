# Runrunrun Android

Android wrapper app for https://runrunrun.cloud/ using Android Browser Helper / Trusted Web Activity.

This public source package intentionally excludes private release-signing material. GitHub Actions builds an installable debug APK for testing.
